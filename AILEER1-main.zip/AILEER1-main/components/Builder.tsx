import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Copy, RefreshCw, Layers, Zap, Briefcase, Palette, Video, Lock, Crown, Film, CreditCard } from 'lucide-react';
import { generateAutoPrompt, generateBuilderPrompt, analyzeBrand, generateBrandVideoPrompt, generateVeoPrompt } from '../services/aiService';
import { BrandProfile, Language } from '../types';
import { translations } from '../services/translations';

interface Props {
  lang: Language;
}

export const Builder: React.FC<Props> = ({ lang }) => {
  const t = translations[lang].builder;
  const [mode, setMode] = useState<'auto' | 'manual' | 'brand' | 'veo'>('auto');
  const [generated, setGenerated] = useState('');
  const [loading, setLoading] = useState(false);
  const [credits, setCredits] = useState(() => {
    const saved = localStorage.getItem('aileer_credits');
    return saved ? parseInt(saved) : 2;
  });
  const [subscription, setSubscription] = useState<'free' | 'pro' | 'ultra'>('free');
  const [showPaywall, setShowPaywall] = useState(false);
  
  // Manual State
  const [step, setStep] = useState(1);
  const [subject, setSubject] = useState('');
  const [style, setStyle] = useState('');
  const [mood, setMood] = useState('');
  const [quality, setQuality] = useState('');

  // Brand State
  const [brandInput, setBrandInput] = useState('');
  const [brandStep, setBrandStep] = useState<'input' | 'analyzing' | 'result'>('input');
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [scanText, setScanText] = useState('Initializing scan...');
  const [brandProfile, setBrandProfile] = useState<BrandProfile | null>(null);

  // Veo State
  const [veoSubject, setVeoSubject] = useState('');

  useEffect(() => {
    localStorage.setItem('aileer_credits', credits.toString());
  }, [credits]);

  const checkLimits = (requiredTier: 'free' | 'pro' | 'ultra' = 'free') => {
    if (requiredTier === 'ultra' && subscription !== 'ultra') {
      setShowPaywall(true);
      return false;
    }
    if (credits <= 0 && subscription === 'free') {
      setShowPaywall(true);
      return false;
    }
    return true;
  };

  const deductCredit = () => {
    if (subscription === 'free') {
      setCredits(prev => prev - 1);
    }
  };

  const handleAutoGenerate = async () => {
    if (!checkLimits()) return;
    setLoading(true);
    setGenerated('');
    const result = await generateAutoPrompt();
    setGenerated(result);
    setLoading(false);
    deductCredit();
  };

  const handleManualComplete = () => {
    if (!checkLimits()) return;
    const res = generateBuilderPrompt(subject, style, mood, quality);
    setGenerated(res);
    deductCredit();
  };

  const handleBrandAnalysis = async () => {
    if (!brandInput) return;
    if (!checkLimits()) return;

    setBrandStep('analyzing');
    setAnalysisProgress(0);
    
    // Scan text logic slightly simpler here for translation purposes
    const steps = [
      { p: 10, t: 'Resolving DNS...' },
      { p: 30, t: 'Fetching assets...' },
      { p: 50, t: 'Analyzing colors...' },
      { p: 80, t: 'Matching industry...' },
      { p: 100, t: 'Done.' }
    ];

    steps.forEach((s, i) => {
      setTimeout(() => {
        setAnalysisProgress(s.p);
        setScanText(s.t);
      }, i * 500);
    });

    try {
      const profile = await analyzeBrand(brandInput);
      setBrandProfile(profile);
      
      setTimeout(() => {
        const prompt = generateBrandVideoPrompt(profile);
        setGenerated(prompt);
        setBrandStep('result');
        deductCredit();
      }, 2600);
    } catch (e) {
      setBrandStep('input');
      alert("Could not analyze domain. Please try again.");
    }
  };

  const handleVeoGenerate = () => {
    if (!checkLimits('ultra')) return;
    setLoading(true);
    setTimeout(() => {
      const res = generateVeoPrompt(veoSubject);
      setGenerated(res);
      setLoading(false);
    }, 2000);
  };

  const handleSubscribe = (tier: 'pro' | 'ultra') => {
    setLoading(true);
    setTimeout(() => {
      setSubscription(tier);
      setShowPaywall(false);
      setLoading(false);
      alert(`Successfully upgraded to ${tier.toUpperCase()}!`);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generated);
    alert(t.copied);
  };

  // Manual Mode Labels
  const manualSteps = {
    1: ['Mystical Dragon', 'Cyberpunk City', 'Portrait Model', 'Abstract'],
    2: ['Hyperrealistic 8K', 'Anime Studio', 'Oil Painting', '3D Render'],
    3: ['Dark & Moody', 'Bright & Vibrant', 'Ethereal', 'Industrial'],
    4: ['Masterpiece 8K', '4K Detailed', 'Cinematic']
  };

  return (
    <div className="min-h-screen pt-32 pb-20 px-4 md:px-8 relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold mb-4">{t.title}</h2>
          <div className="flex justify-center items-center gap-4 text-xs tracking-widest uppercase text-neutral-500">
             <span>{t.mode}: {subscription.toUpperCase()}</span>
             <span className="w-1 h-1 bg-neutral-700 rounded-full"/>
             <span>{t.credits}: {subscription === 'free' ? credits : '∞'}</span>
          </div>
        </div>

        {/* Engine Switcher */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <button
            onClick={() => setMode('auto')}
            className={`px-6 py-3 border transition-all duration-300 flex items-center gap-2 uppercase text-xs tracking-widest ${
              mode === 'auto' ? 'bg-white text-black border-white' : 'border-neutral-800 text-neutral-500 hover:border-neutral-600'
            }`}
          >
            <Zap size={14} /> {t.auto}
          </button>
          <button
            onClick={() => setMode('manual')}
            className={`px-6 py-3 border transition-all duration-300 flex items-center gap-2 uppercase text-xs tracking-widest ${
              mode === 'manual' ? 'bg-white text-black border-white' : 'border-neutral-800 text-neutral-500 hover:border-neutral-600'
            }`}
          >
            <Layers size={14} /> {t.manual}
          </button>
          <button
            onClick={() => setMode('brand')}
            className={`px-6 py-3 border transition-all duration-300 flex items-center gap-2 uppercase text-xs tracking-widest ${
              mode === 'brand' ? 'bg-white text-black border-white' : 'border-neutral-800 text-neutral-500 hover:border-neutral-600'
            }`}
          >
            <Briefcase size={14} /> {t.brand}
          </button>
          <button
            onClick={() => setMode('veo')}
            className={`px-6 py-3 border transition-all duration-300 flex items-center gap-2 uppercase text-xs tracking-widest relative overflow-hidden ${
              mode === 'veo' ? 'bg-gradient-to-r from-purple-900 to-indigo-900 border-indigo-500 text-white' : 'border-neutral-800 text-neutral-500 hover:border-neutral-600'
            }`}
          >
            <Film size={14} /> {t.veo} <span className="absolute top-0 right-0 p-0.5 bg-yellow-500 text-black text-[8px] font-bold">{t.ultra}</span>
          </button>
        </div>

        <div className="glass-panel p-8 md:p-12 rounded-sm min-h-[400px] relative overflow-hidden flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            
            {/* AUTO MODE */}
            {mode === 'auto' && (
              <motion.div key="auto" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center w-full text-center">
                {!generated && !loading && (
                  <div className="max-w-md">
                    <Sparkles className="w-16 h-16 mx-auto mb-6 text-neutral-700" />
                    <h3 className="text-2xl font-serif mb-4">{t.neuralTitle}</h3>
                    <p className="text-neutral-500 mb-8">{t.neuralDesc}</p>
                    <button onClick={handleAutoGenerate} className="px-8 py-4 bg-white text-black text-sm font-bold uppercase tracking-widest hover:scale-105 transition-transform">
                      {t.generateBtn} ({subscription === 'free' ? credits : '∞'})
                    </button>
                  </div>
                )}
                {loading && <div className="w-16 h-16 border-t-2 border-white rounded-full animate-spin" />}
                {generated && !loading && (
                  <OutputDisplay t={t} generated={generated} onCopy={copyToClipboard} onRegen={handleAutoGenerate} />
                )}
              </motion.div>
            )}

            {/* MANUAL MODE */}
            {mode === 'manual' && (
              <motion.div key="manual" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full">
                {!generated ? (
                  <div className="max-w-xl mx-auto w-full">
                     <div className="flex justify-between mb-8 text-xs uppercase tracking-widest text-neutral-500">
                        <span>{t.step} {step} / 4</span>
                     </div>
                     <div className="grid gap-3">
                        {step === 1 && manualSteps[1].map(s => (
                          <StepBtn key={s} label={s} onClick={() => { setSubject(s); setStep(2); }} />
                        ))}
                        {step === 2 && manualSteps[2].map(s => (
                          <StepBtn key={s} label={s} onClick={() => { setStyle(s); setStep(3); }} />
                        ))}
                        {step === 3 && manualSteps[3].map(s => (
                          <StepBtn key={s} label={s} onClick={() => { setMood(s); setStep(4); }} />
                        ))}
                        {step === 4 && manualSteps[4].map(s => (
                          <StepBtn key={s} label={s} onClick={() => { setQuality(s); handleManualComplete(); }} />
                        ))}
                     </div>
                  </div>
                ) : (
                  <OutputDisplay t={t} generated={generated} onCopy={copyToClipboard} onRegen={() => { setGenerated(''); setStep(1); }} />
                )}
              </motion.div>
            )}

            {/* BRAND MODE */}
            {mode === 'brand' && (
              <motion.div key="brand" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full">
                {brandStep === 'input' && (
                  <div className="max-w-md mx-auto text-center">
                    <Briefcase className="w-12 h-12 mx-auto mb-6 text-neutral-500" />
                    <h3 className="text-2xl font-serif mb-2">{t.identityScraper}</h3>
                    <p className="text-neutral-500 mb-8 text-sm">{t.identityDesc}</p>
                    <div className="relative mb-6">
                      <input
                        type="text"
                        value={brandInput}
                        onChange={(e) => setBrandInput(e.target.value)}
                        placeholder={t.placeholder}
                        className="w-full bg-black border border-neutral-700 p-4 text-center text-white placeholder-neutral-600 focus:border-white outline-none transition-colors"
                      />
                    </div>
                    <button onClick={handleBrandAnalysis} className="px-8 py-4 bg-white text-black text-sm font-bold uppercase tracking-widest hover:scale-105 transition-transform">
                      {t.analyzeBtn} ({subscription === 'free' ? credits : '∞'})
                    </button>
                  </div>
                )}
                {brandStep === 'analyzing' && (
                  <div className="max-w-md mx-auto text-center">
                    <div className="w-full bg-neutral-900 h-1 mb-8 overflow-hidden">
                      <motion.div className="bg-white h-full" initial={{ width: 0 }} animate={{ width: `${analysisProgress}%` }} transition={{ duration: 0.5 }} />
                    </div>
                    <div className="font-mono text-xs text-green-500 mb-2">{'>'} {scanText}</div>
                  </div>
                )}
                {brandStep === 'result' && brandProfile && (
                  <div className="w-full">
                    <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-neutral-900/50 p-6 border border-neutral-800">
                        <div className="flex items-center gap-4 mb-4">
                           <div className="w-16 h-16 bg-white/5 rounded-full p-2 flex items-center justify-center border border-white/10">
                              <img src={brandProfile.logoUrl} alt="logo" className="max-w-full max-h-full object-contain" onError={(e) => (e.currentTarget.style.display = 'none')} />
                           </div>
                           <div>
                              <div className="text-lg font-bold">{brandProfile.name}</div>
                              <div className="text-xs text-neutral-500">{brandProfile.domain}</div>
                           </div>
                        </div>
                        <div className="flex gap-2">
                           <div className="h-6 flex-1 rounded-sm" style={{ backgroundColor: brandProfile.primaryColor }}></div>
                           <div className="h-6 flex-1 rounded-sm" style={{ backgroundColor: brandProfile.secondaryColor }}></div>
                        </div>
                      </div>
                      <div className="bg-neutral-900/50 p-6 border border-neutral-800 flex flex-col justify-center">
                         <h4 className="flex items-center gap-2 text-xs uppercase tracking-widest text-neutral-400 mb-2">{t.strategy}</h4>
                         <p className="text-neutral-300 text-sm">{brandProfile.vibe} {t.marketingAsset}</p>
                      </div>
                    </div>
                    <OutputDisplay t={t} generated={generated} onCopy={copyToClipboard} onRegen={() => { setBrandInput(''); setBrandStep('input'); }} />
                  </div>
                )}
              </motion.div>
            )}

            {/* VEO MODE */}
            {mode === 'veo' && (
              <motion.div key="veo" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center w-full text-center">
                {!generated && !loading && (
                  <div className="max-w-md">
                    <div className="relative inline-block mb-6">
                       <Film className="w-16 h-16 mx-auto text-purple-400" />
                       <Crown className="w-6 h-6 absolute -top-2 -right-2 text-yellow-500 animate-pulse" />
                    </div>
                    <h3 className="text-2xl font-serif mb-2">{t.veoTitle}</h3>
                    <p className="text-purple-300/60 mb-8 text-sm uppercase tracking-widest">{t.veoDesc}</p>
                    
                    <textarea 
                      value={veoSubject}
                      onChange={(e) => setVeoSubject(e.target.value)}
                      placeholder={t.veoPlaceholder}
                      className="w-full bg-black/50 border border-purple-900/50 p-4 mb-6 text-white placeholder-purple-900/50 focus:border-purple-500 outline-none rounded-sm min-h-[100px]"
                    />

                    <button 
                      onClick={handleVeoGenerate} 
                      className="w-full px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-sm font-bold uppercase tracking-widest hover:scale-105 transition-transform"
                    >
                      {t.veoBtn}
                    </button>
                  </div>
                )}
                {loading && <div className="w-16 h-16 border-t-2 border-purple-500 rounded-full animate-spin" />}
                {generated && !loading && (
                  <OutputDisplay t={t} generated={generated} onCopy={copyToClipboard} onRegen={() => setGenerated('')} />
                )}
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>

      {/* PAYWALL MODAL */}
      <AnimatePresence>
        {showPaywall && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4"
          >
            <motion.div 
               initial={{ scale: 0.9, y: 20 }}
               animate={{ scale: 1, y: 0 }}
               className="bg-neutral-900 border border-neutral-800 p-8 rounded-sm max-w-4xl w-full relative"
            >
              <button onClick={() => setShowPaywall(false)} className="absolute top-4 right-4 text-neutral-500 hover:text-white">X</button>
              
              <div className="text-center mb-12">
                <h2 className="text-3xl font-serif text-white mb-2">{t.upgradeTitle}</h2>
                <p className="text-neutral-400">{t.upgradeDesc}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Pay Per Use */}
                <div className="bg-black/50 border border-neutral-800 p-6 flex flex-col hover:border-neutral-600 transition-colors">
                  <div className="mb-4">
                    <span className="text-xs uppercase tracking-widest text-neutral-500">{t.refill}</span>
                    <h3 className="text-2xl font-bold text-white">€1.50</h3>
                  </div>
                  <ul className="space-y-3 mb-8 flex-1">
                    <li className="text-sm text-neutral-300 flex items-center gap-2"><CreditCard size={14}/> 2 {t.credits}</li>
                    <li className="text-sm text-neutral-300 flex items-center gap-2"><Lock size={14} className="text-neutral-600"/> {t.noVeo}</li>
                  </ul>
                  <button onClick={() => { setCredits(credits + 2); setShowPaywall(false); alert('2 Credits Added!'); }} className="w-full py-3 border border-white text-white hover:bg-white hover:text-black transition-colors text-xs uppercase tracking-widest font-bold">
                    {t.buyCredits}
                  </button>
                </div>

                {/* Monthly Pro */}
                <div className="bg-neutral-800/50 border border-neutral-700 p-6 flex flex-col scale-105 shadow-2xl relative">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white text-black text-[10px] font-bold px-3 py-1 uppercase tracking-widest">
                    {t.bestValue}
                  </div>
                  <div className="mb-4">
                    <span className="text-xs uppercase tracking-widest text-neutral-400">{t.monthlyPro}</span>
                    <h3 className="text-2xl font-bold text-white">€9.99<span className="text-sm font-normal text-neutral-500">/mo</span></h3>
                  </div>
                  <ul className="space-y-3 mb-8 flex-1">
                    <li className="text-sm text-white flex items-center gap-2"><Zap size={14} className="text-yellow-400"/> {t.unlimited}</li>
                    <li className="text-sm text-white flex items-center gap-2"><Briefcase size={14}/> {t.customBrand}</li>
                    <li className="text-sm text-white flex items-center gap-2"><Palette size={14}/> {t.customBrand}</li>
                  </ul>
                  <button onClick={() => handleSubscribe('pro')} className="w-full py-3 bg-white text-black hover:bg-neutral-200 transition-colors text-xs uppercase tracking-widest font-bold">
                    {t.subscribePro}
                  </button>
                </div>

                {/* ULTRA */}
                <div className="bg-gradient-to-b from-purple-900/20 to-black border border-purple-500/30 p-6 flex flex-col relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-20 h-20 bg-purple-600/20 blur-xl"></div>
                  <div className="mb-4 relative z-10">
                    <span className="text-xs uppercase tracking-widest text-purple-400 flex items-center gap-1"><Crown size={12}/> {t.ultra}</span>
                    <h3 className="text-2xl font-bold text-white">€19.99<span className="text-sm font-normal text-neutral-500">/mo</span></h3>
                  </div>
                  <ul className="space-y-3 mb-8 flex-1 relative z-10">
                    <li className="text-sm text-white flex items-center gap-2"><Zap size={14} className="text-yellow-400"/> {t.unlimited}</li>
                    <li className="text-sm text-white flex items-center gap-2"><Film size={14} className="text-purple-400"/> {t.veoTitle}</li>
                    <li className="text-sm text-white flex items-center gap-2"><Crown size={14} className="text-purple-400"/> {t.priority}</li>
                  </ul>
                  <button onClick={() => handleSubscribe('ultra')} className="w-full py-3 bg-purple-600 text-white hover:bg-purple-500 transition-colors text-xs uppercase tracking-widest font-bold relative z-10">
                    {t.unlockUltra}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const StepBtn: React.FC<{ label: string; onClick: () => void }> = ({ label, onClick }) => (
  <button onClick={onClick} className="p-4 border border-neutral-800 hover:border-white hover:bg-white/5 text-left transition-colors text-sm text-neutral-300">
    {label}
  </button>
);

const OutputDisplay: React.FC<{ generated: string; onCopy: () => void; onRegen: () => void; t: any }> = ({ generated, onCopy, onRegen, t }) => (
  <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="mb-2 text-left text-xs text-neutral-500 uppercase tracking-widest">{t.neuralOutput}</div>
    <div className="bg-black/50 border border-neutral-800 p-6 rounded-sm text-left font-mono text-neutral-300 leading-relaxed mb-8 break-words whitespace-pre-wrap">
      {generated}
    </div>
    <div className="flex gap-4 justify-center">
      <button onClick={onCopy} className="px-6 py-3 border border-white text-white hover:bg-white hover:text-black transition-colors flex items-center gap-2 text-xs uppercase tracking-widest">
        <Copy size={14} /> {t.copy}
      </button>
      <button onClick={onRegen} className="px-6 py-3 border border-neutral-800 text-neutral-400 hover:border-white hover:text-white transition-colors flex items-center gap-2 text-xs uppercase tracking-widest">
        <RefreshCw size={14} /> {t.regenerate}
      </button>
    </div>
  </div>
);