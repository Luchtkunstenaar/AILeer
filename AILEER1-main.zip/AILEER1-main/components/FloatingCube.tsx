import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// A sophisticated "Surprise Box" replacement.
// It floats in the corner. When clicked, it opens a random high-value link.
export const FloatingCube: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleClick = () => {
    // Open a random affiliate link
    const links = [
      'https://t.me/blum/app?startapp=ref_7ZBeiLONAP',
      'https://everpress.com/free-bifi'
    ];
    const link = links[Math.floor(Math.random() * links.length)];
    window.open(link, '_blank');
    setIsOpen(true);
    setTimeout(() => setIsOpen(false), 2000);
  };

  return (
    <motion.div
      className="fixed bottom-8 right-8 z-40 cursor-pointer hidden md:block"
      animate={{ 
        y: [0, -10, 0],
        rotate: [0, 5, -5, 0]
      }}
      transition={{ 
        duration: 6, 
        repeat: Infinity,
        ease: "easeInOut" 
      }}
      onClick={handleClick}
    >
      <div className="w-16 h-16 relative preserve-3d group">
        <div className="absolute inset-0 border border-white/20 bg-black/50 backdrop-blur-sm flex items-center justify-center transform group-hover:scale-110 transition-transform duration-500">
           <span className="text-2xl opacity-50 group-hover:opacity-100">🎁</span>
        </div>
        {/* Glow effect */}
        <div className="absolute inset-0 bg-white/5 blur-xl -z-10 group-hover:bg-white/10 transition-colors" />
      </div>
    </motion.div>
  );
};