import React from 'react';
import { Language } from '../types';
import { translations } from '../services/translations';

interface Props {
  lang: Language;
}

export const Footer: React.FC<Props> = ({ lang }) => {
  const t = translations[lang].footer;

  return (
    <footer className="border-t border-neutral-900 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <h4 className="font-serif font-bold text-xl mb-2">AILEER.NL</h4>
          <p className="text-xs text-neutral-600 uppercase tracking-widest">
            {t.rights}
          </p>
        </div>
        
        <div className="flex gap-6 text-xs text-neutral-500 tracking-widest uppercase">
          <a href="https://youtube.com/@aileernl" target="_blank" className="hover:text-white transition-colors">YouTube</a>
          <a href="#" className="hover:text-white transition-colors">{t.privacy}</a>
          <a href="#" className="hover:text-white transition-colors">{t.terms}</a>
        </div>
      </div>
    </footer>
  );
};