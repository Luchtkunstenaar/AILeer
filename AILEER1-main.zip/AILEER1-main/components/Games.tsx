import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink } from 'lucide-react';
import { AffiliateGame, Language } from '../types';
import { translations } from '../services/translations';

const games: AffiliateGame[] = [
  {
    name: "BLUM Mining",
    descriptionEn: "The next generation exchange. Mine tokens directly in Telegram.",
    descriptionNl: "De next-gen exchange. Mine tokens direct in Telegram.",
    url: "https://t.me/blum/app?startapp=ref_7ZBeiLONAP",
    icon: "💎",
    tag: "Trending"
  },
  {
    name: "Frens AI",
    descriptionEn: "Create your own AI twin and earn rewards on the blockchain.",
    descriptionNl: "Maak je eigen AI-tweeling en verdien beloningen op de blockchain.",
    url: "https://t.me/FrensAIbot/app?startapp=019a59cf-5e33-7315-a2fb-bbc1274e595f",
    icon: "🤖",
    tag: "AI Powered"
  },
  {
    name: "TON Kombat",
    descriptionEn: "Battle other players in this high-stakes arena game.",
    descriptionNl: "Vecht tegen andere spelers in deze high-stakes arena game.",
    url: "https://t.me/tonkombat_bot/start?startapp=ref_406398865",
    icon: "⚔️",
    tag: "P2E"
  },
  {
    name: "LIONS",
    descriptionEn: "King of the jungle ecosystem. Tap to earn mechanics.",
    descriptionNl: "Koning van de jungle. Tap-to-earn mechanisme.",
    url: "https://t.me/Lionsapp_bot/LIONS?startapp=r_406398865",
    icon: "🦁",
    tag: "New"
  }
];

interface Props {
  lang: Language;
}

export const Games: React.FC<Props> = ({ lang }) => {
  const t = translations[lang].games;

  return (
    <div className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-16 border-l-2 border-white pl-6">
          <h2 className="text-4xl md:text-6xl font-serif font-bold mb-4">{t.title}</h2>
          <p className="text-neutral-400 max-w-xl text-lg">
            {t.desc}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {games.map((game, idx) => (
            <motion.a
              key={game.name}
              href={game.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="group relative block h-64 overflow-hidden border border-neutral-800 bg-neutral-900/30 hover:border-white/50 transition-all duration-500"
            >
              {/* Background Glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-neutral-800/20 to-transparent group-hover:from-neutral-700/30 transition-all duration-500" />
              
              <div className="absolute top-6 right-6 flex items-center gap-2">
                 <span className="px-3 py-1 bg-white/10 text-[10px] uppercase tracking-widest rounded-full backdrop-blur-sm border border-white/5">
                   {game.tag}
                 </span>
                 <ExternalLink className="text-neutral-500 group-hover:text-white transition-colors" size={16} />
              </div>

              <div className="absolute bottom-0 left-0 p-8 w-full">
                <div className="text-4xl mb-4 transform group-hover:-translate-y-2 transition-transform duration-500">{game.icon}</div>
                <h3 className="text-2xl font-serif font-bold mb-2 group-hover:text-white transition-colors">{game.name}</h3>
                <p className="text-neutral-400 text-sm leading-relaxed max-w-md group-hover:text-neutral-300">
                  {lang === 'en' ? game.descriptionEn : game.descriptionNl}
                </p>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </div>
  );
};