
import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Command, GitBranch, Wand2, Clock, BarChart } from 'lucide-react';
import { GuideItem, Language } from '../types';
import { translations } from '../services/translations';

interface Props {
  lang: Language;
}

const guidesList: GuideItem[] = [
  {
    id: '1',
    titleEn: 'Midjourney V6: The Photorealism Protocols',
    titleNl: 'Midjourney V6: De Fotorealisme Protocollen',
    descEn: 'Deep dive into --style raw and --s parameters to achieve indistinguishable-from-reality photography. Learn the "Subject-Camera-Light" syntax.',
    descNl: 'Diepte-analyse van --style raw en --s parameters voor levensechte fotografie. Leer de "Onderwerp-Camera-Licht" syntax.',
    difficulty: 'Expert',
    readTime: '8 min',
    tags: ['Midjourney', 'Photography']
  },
  {
    id: '2',
    titleEn: 'DALL-E 3: Semantic Consistency',
    titleNl: 'DALL-E 3: Semantische Consistentie',
    descEn: 'How to use Seed Numbers and Gen_ID to maintain character identity across multiple scenes. Essential for storyboarding and comics.',
    descNl: 'Hoe je Seed Numbers en Gen_ID gebruikt om karakters consistent te houden. Essentieel voor storyboards en strips.',
    difficulty: 'Intermediate',
    readTime: '5 min',
    tags: ['DALL-E', 'Workflow']
  },
  {
    id: '3',
    titleEn: 'Stable Diffusion: ControlNet Mastery',
    titleNl: 'Stable Diffusion: ControlNet Meesterschap',
    descEn: 'Stop rolling dice. Use OpenPose and Canny edge detection to force the AI to follow your exact composition and pose requirements.',
    descNl: 'Stop met gokken. Gebruik OpenPose en Canny edge detectie om de AI jouw exacte compositie en pose te laten volgen.',
    difficulty: 'Expert',
    readTime: '12 min',
    tags: ['Stable Diffusion', 'Technical']
  },
  {
    id: '4',
    titleEn: 'The Art of Prompt Weighting',
    titleNl: 'De Kunst van Prompt Weging',
    descEn: 'Understanding multi-prompting (::) and token weight brackets () to control which elements dominate your image generation.',
    descNl: 'Begrijp multi-prompting (::) en token gewichten () om te controleren welke elementen je afbeelding domineren.',
    difficulty: 'Beginner',
    readTime: '4 min',
    tags: ['General', 'Syntax']
  }
];

export const Guides: React.FC<Props> = ({ lang }) => {
  const t = translations[lang].guides;

  return (
    <div className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16 border-l-2 border-white pl-6">
          <h2 className="text-4xl md:text-6xl font-serif font-bold mb-4">{t.title}</h2>
          <p className="text-neutral-400 max-w-xl text-lg">
            {t.desc}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {guidesList.map((guide, idx) => (
            <motion.div
              key={guide.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="group bg-neutral-900/40 border border-neutral-800 p-8 hover:border-neutral-600 transition-all duration-300 hover:bg-neutral-900/60"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="flex gap-2">
                  {guide.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 bg-white/5 text-[10px] uppercase tracking-widest text-neutral-400 border border-white/5">
                      {tag}
                    </span>
                  ))}
                </div>
                <Wand2 className="text-neutral-600 group-hover:text-white transition-colors" size={20} />
              </div>

              <h3 className="text-2xl font-serif font-bold mb-4 group-hover:text-white transition-colors">
                {lang === 'en' ? guide.titleEn : guide.titleNl}
              </h3>
              
              <p className="text-neutral-400 leading-relaxed mb-8 min-h-[80px]">
                {lang === 'en' ? guide.descEn : guide.descNl}
              </p>

              <div className="flex items-center justify-between border-t border-neutral-800 pt-6">
                <div className="flex gap-6 text-xs text-neutral-500 font-mono">
                  <span className="flex items-center gap-2">
                    <BarChart size={12} /> {guide.difficulty}
                  </span>
                  <span className="flex items-center gap-2">
                    <Clock size={12} /> {guide.readTime}
                  </span>
                </div>
                
                <button className="text-xs uppercase tracking-widest text-white border-b border-white pb-1 hover:text-neutral-300 hover:border-neutral-300 transition-colors">
                  {t.readMore}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
