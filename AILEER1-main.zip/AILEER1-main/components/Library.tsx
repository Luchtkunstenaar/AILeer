import React, { useState } from 'react';
import { promptLibrary } from '../services/aiService';
import { motion } from 'framer-motion';
import { Copy } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../services/translations';

interface Props {
  lang: Language;
}

export const Library: React.FC<Props> = ({ lang }) => {
  const [filter, setFilter] = useState('all');
  const t = translations[lang].library;

  const filtered = filter === 'all' 
    ? promptLibrary 
    : promptLibrary.filter(p => p.category === filter);

  // Map category IDs to translated strings
  const categories = [
    { id: 'all', label: t.all },
    { id: 'photography', label: t.photography },
    { id: 'art', label: t.art },
    { id: 'fantasy', label: t.fantasy },
    { id: 'sci-fi', label: t.sciFi }
  ];

  return (
    <div className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-serif font-bold mb-12 text-center">{t.title}</h2>
        
        {/* Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          {categories.map(c => (
            <button
              key={c.id}
              onClick={() => setFilter(c.id)}
              className={`px-4 py-2 text-xs uppercase tracking-widest border transition-colors ${
                filter === c.id ? 'bg-white text-black border-white' : 'border-neutral-800 text-neutral-500 hover:border-neutral-600'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((item) => (
            <motion.div
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              key={item.id}
              className="bg-neutral-900/20 border border-neutral-800 p-8 hover:border-neutral-600 transition-colors group"
            >
              <div className="flex justify-between items-start mb-6">
                <span className="text-[10px] uppercase tracking-widest text-neutral-500 border border-neutral-800 px-2 py-1 rounded-sm">
                  {item.category}
                </span>
                <button 
                  onClick={() => navigator.clipboard.writeText(item.prompt)}
                  className="text-neutral-600 hover:text-white transition-colors"
                >
                  <Copy size={16} />
                </button>
              </div>
              
              <h3 className="text-xl font-serif mb-4 group-hover:text-white transition-colors">{item.title}</h3>
              <p className="text-sm text-neutral-400 font-mono leading-relaxed line-clamp-4 group-hover:line-clamp-none transition-all">
                {item.prompt}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};