import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ShoppingBag } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../services/translations';

interface Props {
  lang: Language;
}

export const Merch: React.FC<Props> = ({ lang }) => {
  const t = translations[lang].merch;

  return (
    <div className="min-h-screen pt-32 pb-20 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        
        {/* Editorial Hero */}
        <div className="relative mb-24">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="aspect-[21/9] w-full bg-neutral-900 border border-neutral-800 relative overflow-hidden group cursor-pointer"
            onClick={() => window.open('https://everpress.com/profile/puluz', '_blank')}
          >
            {/* Abstract Background Art */}
            <div className="absolute inset-0 bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-900 opacity-50" />
            <div className="absolute inset-0 flex items-center justify-center opacity-30">
               <div className="w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[100px] animate-pulse" />
               <div className="w-[300px] h-[300px] bg-blue-900/20 rounded-full blur-[80px] absolute translate-x-32" />
            </div>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 z-10">
              <span className="inline-block px-3 py-1 bg-white text-black text-[10px] font-bold uppercase tracking-widest mb-6">
                {t.limited}
              </span>
              <h1 className="text-5xl md:text-8xl font-serif font-bold text-white mb-4 tracking-tight mix-blend-difference">
                {t.title}
              </h1>
              <p className="text-xl text-neutral-400 font-light tracking-[0.2em] uppercase mb-12">
                {t.subtitle}
              </p>
              
              <motion.button 
                whileHover={{ scale: 1.05 }}
                className="px-8 py-4 bg-white text-black font-bold uppercase tracking-widest flex items-center gap-2"
              >
                {t.shopBtn} <ArrowUpRight size={16} />
              </motion.button>
            </div>
          </motion.div>
        </div>

        {/* Collection Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
             <h2 className="text-3xl font-serif mb-6">{t.desc}</h2>
             <div className="space-y-6 text-neutral-400 leading-relaxed">
               <p>
                 Designed by generative algorithms, curated by humans. The PULUZ collection represents the fusion of artificial imagination and street culture. 
               </p>
               <p>
                 Each piece is printed on high-quality sustainable cotton via Everpress. Available for a limited time only.
               </p>
             </div>
             
             <div className="mt-8 flex gap-4">
               <div className="h-12 w-12 rounded-full border border-neutral-800 bg-neutral-900 flex items-center justify-center">
                 <span className="text-xs">S</span>
               </div>
               <div className="h-12 w-12 rounded-full border border-neutral-800 bg-neutral-900 flex items-center justify-center">
                 <span className="text-xs">M</span>
               </div>
               <div className="h-12 w-12 rounded-full border border-white bg-white text-black flex items-center justify-center font-bold">
                 <span className="text-xs">L</span>
               </div>
               <div className="h-12 w-12 rounded-full border border-neutral-800 bg-neutral-900 flex items-center justify-center">
                 <span className="text-xs">XL</span>
               </div>
             </div>
          </div>

          <div className="relative">
            <div className="aspect-square bg-neutral-900/50 border border-neutral-800 p-12 flex items-center justify-center relative overflow-hidden group">
               <div className="absolute top-4 right-4">
                 <ShoppingBag className="text-neutral-600" />
               </div>
               
               {/* T-Shirt Mockup Abstraction */}
               <motion.div 
                 whileHover={{ scale: 1.05, rotate: -2 }}
                 className="relative w-64 h-80 bg-neutral-800 mask-tshirt flex items-center justify-center"
                 style={{ clipPath: 'polygon(20% 0%, 80% 0%, 100% 20%, 100% 100%, 0% 100%, 0% 20%)' }}
               >
                  <div className="text-center">
                    <div className="text-4xl mb-2">👾</div>
                    <div className="text-[10px] font-mono text-neutral-500 uppercase">Neural <br/> Network</div>
                  </div>
                  
                  <div className="absolute bottom-4 left-0 right-0 text-center">
                    <span className="text-[10px] text-neutral-600">PULUZ x AILEER</span>
                  </div>
               </motion.div>
               
               <div className="absolute bottom-6 left-6">
                 <div className="text-xs text-neutral-500 uppercase tracking-widest">Base Model</div>
                 <div className="text-white font-bold">Classic Tee Black</div>
               </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};