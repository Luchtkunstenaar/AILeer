import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Home, Zap, Library as LibraryIcon, Gamepad2, ShoppingBag, BookOpen } from 'lucide-react';
import { NavItem, Language } from '../types';
import { translations } from '../services/translations';

interface Props {
  activePage: string;
  setActivePage: (page: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const navItems: NavItem[] = [
  { id: 'home', path: 'home' },
  { id: 'builder', path: 'builder' },
  { id: 'library', path: 'library' },
  { id: 'games', path: 'games' },
  { id: 'merch', path: 'merch' },
  { id: 'guides', path: 'guides' },
];

const NavIcon = ({ id, active }: { id: string; active: boolean }) => {
  const props = { 
    size: 20, 
    strokeWidth: 1.5,
    className: `transition-colors duration-300 ${active ? "text-white" : "text-neutral-500 group-hover:text-neutral-300"}` 
  };
  
  switch(id) {
      case 'home': return <Home {...props} />;
      case 'builder': return <Zap {...props} />;
      case 'library': return <LibraryIcon {...props} />;
      case 'games': return <Gamepad2 {...props} />;
      case 'merch': return <ShoppingBag {...props} />;
      case 'guides': return <BookOpen {...props} />;
      default: return <Home {...props} />;
  }
};

export const Navigation: React.FC<Props> = ({ activePage, setActivePage, lang, setLang }) => {
  const [scrolled, setScrolled] = useState(false);
  const t = translations[lang].nav;

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* Top Header - Branding & Language */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-background/80 backdrop-blur-md border-b border-white/5 py-3' : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setActivePage('home')}
          >
            <div className="w-8 h-8 bg-white rounded-sm rotate-45 group-hover:rotate-90 transition-transform duration-500 shadow-[0_0_15px_rgba(255,255,255,0.5)]" />
            <span className="text-xl font-serif font-bold tracking-[0.2em] hidden xs:block">AILEER.NL</span>
          </div>

          <div className="flex gap-2 text-[10px] font-bold tracking-widest bg-white/5 px-4 py-2 rounded-full border border-white/10 backdrop-blur-md hover:bg-white/10 transition-colors">
            <button 
              onClick={() => setLang('en')}
              className={`transition-colors ${lang === 'en' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
            >
              EN
            </button>
            <span className="text-neutral-700">|</span>
            <button 
              onClick={() => setLang('nl')}
              className={`transition-colors ${lang === 'nl' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
            >
              NL
            </button>
          </div>
        </div>
      </motion.header>

      {/* Bottom Navigation Dock - Full width bar on mobile, floating on desktop */}
      <div className="fixed bottom-0 left-0 right-0 z-50 md:p-4 pointer-events-none flex justify-center items-end">
        <motion.nav
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, type: "spring", stiffness: 200, damping: 20 }}
          className="pointer-events-auto bg-neutral-900/95 backdrop-blur-xl border-t border-white/10 md:border md:rounded-2xl px-2 py-3 md:px-8 md:py-3 shadow-2xl shadow-black/80 w-full md:w-auto md:max-w-fit flex justify-around md:justify-center items-center gap-1 md:gap-8 pb-4 md:pb-3"
        >
           {navItems.map((item) => {
             const isActive = activePage === item.path;
             return (
               <button
                 key={item.path}
                 onClick={() => {
                   setActivePage(item.path);
                   window.scrollTo({ top: 0, behavior: 'smooth' });
                 }}
                 className="group flex flex-col items-center justify-center p-1 md:p-2 rounded-xl transition-all relative min-w-[50px] md:min-w-[60px]"
               >
                 {/* Icon Container with Hover Lift */}
                 <div className={`transition-all duration-300 ${isActive ? 'scale-110 -translate-y-1' : 'group-hover:-translate-y-1'}`}>
                    <NavIcon id={item.id} active={isActive} />
                 </div>
                 
                 {/* Label - Visible on mobile now for better UX */}
                 <span className={`text-[9px] uppercase tracking-widest mt-1 transition-all duration-300 ${
                    isActive ? 'text-white opacity-100' : 'text-neutral-500 opacity-70 group-hover:opacity-100'
                 }`}>
                   {t[item.id as keyof typeof t]}
                 </span>
                 
                 {/* Active Indicator Glow - Desktop Only */}
                 {isActive && (
                   <motion.div
                     layoutId="nav-indicator"
                     className="absolute -bottom-1 w-1 h-1 bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,1)] hidden md:block"
                   />
                 )}
               </button>
             );
           })}
        </motion.nav>
      </div>
    </>
  );
};