import { BrandProfile } from '../types';

// This service acts as the "Brain". It costs $0 because it runs in the browser
// but uses complex arrays to generate high-quality outputs.

const subjects = [
  'A cybernetic samurai meditating in a neon garden',
  'An ethereal entity made of stardust and glass',
  'A brutalist concrete megastructure in a desert',
  'A high-fashion portrait of a woman with liquid gold skin',
  'A microscopic view of a mechanical insect',
  'An underwater ballroom filled with bioluminescent jellyfish',
  'A futuristic Formula 1 car racing on a light-cycle track',
  'A solitary astronaut standing on the edge of a black hole',
  'A renaissance style painting of a cat wearing royal robes'
];

const styles = [
  'Hyperrealistic 8K photography',
  'Cinematic Unreal Engine 5 render',
  'Abstract expressionism impasto oil painting',
  'Minimalist vector art',
  'Vintage 1920s film grain noir',
  'Cyberpunk aesthetic with chromatic aberration',
  'Studio Ghibli anime style',
  'Double exposure photography'
];

const moods = [
  'Melancholic and atmospheric',
  'Vibrant and energetic',
  'Dark, mysterious and ominous',
  'Ethereal and dreamy',
  'Clinical and precise',
  'Warm and nostalgic'
];

const technicals = [
  'shot on Sony A7R IV, 85mm f/1.2 lens, global illumination, raytracing',
  'octane render, volumetric lighting, subsurface scattering, 8k resolution',
  'rule of thirds, bokeh, depth of field, masterpiece, trending on ArtStation',
  'cinematic lighting, rim light, highly detailed texture, 4k, sharp focus'
];

export const generateAutoPrompt = (): Promise<string> => {
  // Simulate "Thinking" time for premium feel
  return new Promise((resolve) => {
    setTimeout(() => {
      const s = subjects[Math.floor(Math.random() * subjects.length)];
      const st = styles[Math.floor(Math.random() * styles.length)];
      const m = moods[Math.floor(Math.random() * moods.length)];
      const t = technicals[Math.floor(Math.random() * technicals.length)];
      
      resolve(`${s}, ${st}, ${m}, ${t} --v 6.0`);
    }, 1500);
  });
};

export const generateBuilderPrompt = (subject: string, style: string, mood: string, quality: string): string => {
  return `${subject}, ${style}, ${mood}, ${quality}, highly detailed, professional lighting, masterpiece --ar 16:9`;
};

// --- BRAND IDENTITY ENGINE ---

const industries = [
  { name: 'Tech & SaaS', vibe: 'Clean, Minimalist, Futuristic' },
  { name: 'Luxury Fashion', vibe: 'Elegant, High-Contrast, Serene' },
  { name: 'Food & Beverage', vibe: 'Vibrant, Organic, Appetizing' },
  { name: 'Automotive', vibe: 'Sleek, Dynamic, Metallic' },
  { name: 'Eco & Nature', vibe: 'Earthy, Soft, Natural' },
];

const colors = [
  { p: '#0052FF', s: '#FFFFFF' }, // Tech Blue
  { p: '#000000', s: '#D4AF37' }, // Luxury Gold
  { p: '#FF3B30', s: '#F2F2F7' }, // Bold Red
  { p: '#34C759', s: '#1C1C1E' }, // Eco Green
  { p: '#5856D6', s: '#E5E5EA' }, // Creative Purple
  { p: '#FF9500', s: '#000000' }, // Energy Orange
];

// Deterministic simulation based on string hash
const stringToHash = (string: string) => {
  let hash = 0;
  for (let i = 0; i < string.length; i++) {
    const char = string.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
};

export const analyzeBrand = (input: string): Promise<BrandProfile> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Heuristic to detect or append domain
      const domain = input.includes('.') ? input : `${input.replace(/\s+/g, '').toLowerCase()}.com`;
      const name = input.includes('.') ? input.split('.')[0] : input;
      
      // Use logo.clearbit.com to fetch real logo (Free, reliable)
      const logoUrl = `https://logo.clearbit.com/${domain}`;

      const hash = stringToHash(name);
      const industry = industries[hash % industries.length];
      // We still simulate colors as fallback, or "extracted" metadata logic
      const color = colors[hash % colors.length];

      resolve({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        domain: domain,
        logoUrl: logoUrl,
        industry: industry.name,
        vibe: industry.vibe,
        primaryColor: color.p,
        secondaryColor: color.s
      });
    }, 2500); 
  });
};

export const generateBrandVideoPrompt = (profile: BrandProfile): string => {
  const videoStyles = [
    'Slow motion cinematic product reveal',
    'Dynamic FPV drone flythrough',
    'Macro close-up with depth of field',
    'Commercial TV spot aesthetic'
  ];
  
  const selectedStyle = videoStyles[Math.floor(Math.random() * videoStyles.length)];

  return `Professional Commercial Video for ${profile.name}: ${selectedStyle}.
  
BRANDING ASSETS:
- Official Logo Source: ${profile.logoUrl}
- Primary Color: ${profile.primaryColor}
- Secondary Color: ${profile.secondaryColor}

SCENE DESCRIPTION:
${profile.vibe} atmosphere. The logo is subtly integrated into the environment (e.g. etched on glass, holographic projection, or embroidered on fabric). 
High-budget production value, perfectly lit, 4k resolution, smooth camera movement, color graded to match brand identity. --ar 16:9 --video`;
};

export const generateVeoPrompt = (subject: string): string => {
  return `VEO 3 GENERATION: 
Subject: ${subject}
Motion: Cinematic camera pan, smooth tracking.
Physics: Real-time fluid dynamics and cloth simulation.
Lighting: Volumetric ray-traced lighting.
Resolution: 1080p @ 60fps.
--veo3 --ultra-mode`;
};


// Data for the library
export const promptLibrary = [
  { id: '1', category: 'photography', title: 'Golden Hour Portrait', prompt: 'Portrait of an elderly fisherman, deep wrinkles, piercing blue eyes, golden hour sunlight hitting the side of the face, shot on 35mm film, grainy texture, emotional.' },
  { id: '2', category: 'sci-fi', title: 'Neo-Tokyo Drifter', prompt: 'A sleek motorcycle speeding through a rain-slicked neon city at night, motion blur, cyberpunk aesthetic, purple and teal color palette, volumetric fog.' },
  { id: '3', category: 'fashion', title: 'Vogue Avant-Garde', prompt: 'Full body shot of a model wearing a dress made of flowing water, high fashion editorial, studio lighting, white background, surrealist, 8k.' },
  { id: '4', category: 'fantasy', title: 'Crystal Dragon', prompt: 'A massive dragon made entirely of translucent quartz crystals, resting in a dark cave, glowing from within, cinematic lighting, caustics, sharp details.' },
  { id: '5', category: 'art', title: 'Abstract Chaos', prompt: 'Explosion of colorful paint powder in zero gravity, macro shot, high speed photography, vibrant colors against black background, intense detail.' },
];