
import { Language } from '../types';

export const translations = {
  en: {
    nav: {
      home: 'Home',
      builder: 'AI Builder',
      library: 'Library',
      games: 'Games',
      merch: 'Merch',
      guides: 'Guides',
    },
    hero: {
      badge: 'Architecture for Imagination',
      titleLine1: 'Craft the',
      titleLine2: 'Unimaginable',
      subtitle: "The Netherlands' premier free AI prompt engineering suite. Generate masterpieces for Midjourney, DALL-E & Stable Diffusion instantly.",
      startBtn: 'Start Creating',
      exploreBtn: 'Explore Assets',
      scroll: 'Scroll'
    },
    builder: {
      title: 'Prompt Architect',
      mode: 'Mode',
      credits: 'Credits',
      auto: 'Auto',
      manual: 'Manual',
      brand: 'Brand',
      veo: 'Veo 3',
      ultra: 'Ultra',
      
      // Auto Mode
      neuralTitle: 'Neural Engine',
      neuralDesc: 'One-click generation based on trending aesthetics.',
      generateBtn: 'Generate',
      
      // Manual Mode
      step: 'Step',
      steps: {
        s1: 'Subject',
        s2: 'Style',
        s3: 'Mood',
        s4: 'Quality'
      },
      
      // Brand Mode
      identityScraper: 'Identity Scraper',
      identityDesc: 'Enter a website domain (e.g. nike.com) to fetch official assets.',
      placeholder: 'domain.com',
      analyzeBtn: 'Analyze & Generate',
      strategy: 'Strategy',
      marketingAsset: 'Marketing Asset',
      
      // Veo Mode
      veoTitle: 'Veo 3 Generator',
      veoDesc: 'Ultra-HD Video Generation Engine',
      veoPlaceholder: 'Describe the video scene...',
      veoBtn: 'Generate 1080p Video',
      
      // Output
      neuralOutput: 'Neural Output',
      copy: 'Copy',
      regenerate: 'Regenerate',
      copied: 'Copied to clipboard',
      
      // Paywall
      upgradeTitle: 'Upgrade Your Arsenal',
      upgradeDesc: 'Unlock professional limits and next-gen engines.',
      refill: 'Refill',
      buyCredits: 'Buy Credits',
      monthlyPro: 'Monthly Pro',
      subscribePro: 'Subscribe Pro',
      bestValue: 'Best Value',
      unlockUltra: 'Unlock Ultra',
      noVeo: 'No Veo 3 Access',
      unlimited: 'Unlimited Image Prompts',
      customBrand: 'Custom Brand Profiles',
      priority: 'Priority Processing',
    },
    library: {
      title: 'Curated Library',
      all: 'All',
      photography: 'Photography',
      art: 'Art',
      fantasy: 'Fantasy',
      sciFi: 'Sci-Fi'
    },
    games: {
      title: 'TON Ecosystem',
      desc: 'Curated selection of high-yield blockchain gaming opportunities. Play, earn, and leverage AI in the Web3 space.',
    },
    guides: {
      title: 'Knowledge Base',
      desc: 'Master the algorithms. Advanced techniques for the modern prompt engineer.',
      readMore: 'Read Analysis',
      difficulty: 'Difficulty',
      time: 'Read Time'
    },
    merch: {
      title: 'PULUZ Collection',
      subtitle: 'Wearable Algorithms',
      desc: 'Limited edition streetwear designed by neural networks. The intersection of code and couture.',
      shopBtn: 'Shop Collection',
      limited: 'Limited Edition Drop'
    },
    footer: {
      rights: '© 2025 Masterpiece Edition. All Rights Reserved.',
      privacy: 'Privacy',
      terms: 'Terms'
    }
  },
  nl: {
    nav: {
      home: 'Home',
      builder: 'AI Bouwer',
      library: 'Bieb',
      games: 'Games',
      merch: 'Merch',
      guides: 'Gidsen',
    },
    hero: {
      badge: 'Architectuur voor Verbeelding',
      titleLine1: 'Creëer het',
      titleLine2: 'Onvoorstelbare',
      subtitle: "Nederlands nummer 1 gratis AI prompt suite. Genereer direct meesterwerken voor Midjourney, DALL-E & Stable Diffusion.",
      startBtn: 'Start Creëren',
      exploreBtn: 'Ontdek Assets',
      scroll: 'Scroll'
    },
    builder: {
      title: 'Prompt Architect',
      mode: 'Modus',
      credits: 'Credits',
      auto: 'Auto',
      manual: 'Handmatig',
      brand: 'Merk',
      veo: 'Veo 3',
      ultra: 'Ultra',
      
      // Auto Mode
      neuralTitle: 'Neurale Engine',
      neuralDesc: 'Eén-klik generatie gebaseerd op trending esthetiek.',
      generateBtn: 'Genereer',
      
      // Manual Mode
      step: 'Stap',
      steps: {
        s1: 'Onderwerp',
        s2: 'Stijl',
        s3: 'Sfeer',
        s4: 'Kwaliteit'
      },
      
      // Brand Mode
      identityScraper: 'Identiteit Scraper',
      identityDesc: 'Vul een domeinnaam in (bijv. nike.com) om officiële assets op te halen.',
      placeholder: 'domein.com',
      analyzeBtn: 'Analyseer & Genereer',
      strategy: 'Strategie',
      marketingAsset: 'Marketing Asset',
      
      // Veo Mode
      veoTitle: 'Veo 3 Generator',
      veoDesc: 'Ultra-HD Video Generatie Engine',
      veoPlaceholder: 'Beschrijf de videoscene...',
      veoBtn: 'Genereer 1080p Video',
      
      // Output
      neuralOutput: 'Neurale Output',
      copy: 'Kopieer',
      regenerate: 'Opnieuw',
      copied: 'Gekopieerd naar klembord',
      
      // Paywall
      upgradeTitle: 'Upgrade Je Arsenaal',
      upgradeDesc: 'Ontgrendel professionele limieten en next-gen engines.',
      refill: 'Navullen',
      buyCredits: 'Koop Credits',
      monthlyPro: 'Maandelijks Pro',
      subscribePro: 'Abonneer Pro',
      bestValue: 'Beste Keus',
      unlockUltra: 'Ontgrendel Ultra',
      noVeo: 'Geen Veo 3 Toegang',
      unlimited: 'Onbeperkte Image Prompts',
      customBrand: 'Custom Merk Profielen',
      priority: 'Prioriteit Verwerking',
    },
    library: {
      title: 'Gecureerde Bibliotheek',
      all: 'Alles',
      photography: 'Fotografie',
      art: 'Kunst',
      fantasy: 'Fantasie',
      sciFi: 'Sci-Fi'
    },
    games: {
      title: 'TON Ecosysteem',
      desc: 'Geselecteerde blockchain gaming kansen met hoog rendement. Speel, verdien en gebruik AI in de Web3 ruimte.',
    },
    guides: {
      title: 'Kennisbank',
      desc: 'Beheers de algoritmes. Geavanceerde technieken voor de moderne prompt engineer.',
      readMore: 'Lees Analyse',
      difficulty: 'Niveau',
      time: 'Leestijd'
    },
    merch: {
      title: 'PULUZ Collectie',
      subtitle: 'Draagbare Algoritmes',
      desc: 'Limited edition streetwear ontworpen door neurale netwerken. Het kruispunt van code en couture.',
      shopBtn: 'Bekijk Collectie',
      limited: 'Limited Edition Drop'
    },
    footer: {
      rights: '© 2025 Masterpiece Editie. Alle Rechten Voorbehouden.',
      privacy: 'Privacy',
      terms: 'Voorwaarden'
    }
  }
};
